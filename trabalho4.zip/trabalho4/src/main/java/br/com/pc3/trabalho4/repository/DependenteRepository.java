package br.com.pc3.trabalho4.repository;

import org.springframework.data.repository.CrudRepository;
import br.com.pc3.trabalho4.domain.Dependente;

public interface DependenteRepository extends CrudRepository<Dependente, Long>{

}
