# trabalho4PC3
Crie um webservice para fazer CRUD das tabelas criadas no trabalho anterior: empregado (cpf, nome, idade, salario) e dependente (cpfEmpregado, nome, grauParentesco, dataNascimento);
